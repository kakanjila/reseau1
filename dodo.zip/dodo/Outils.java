import java.io.*;
public class Outils {
    public static final String absoluteDirectoryPath = "D:\\repository";  //stocke reassemble distant


    public static final String repertoire_partage = "D:\\repository"; // dossier du server partager pour le telechargement

    public static final int CLIENT_PORT_swing = 12345; 
    public static final String CLIENT_HOST_swing = "localhost"; 

    public static final String SERVER_IP_SWING = "localhost"; 
    public static final int PORT_SWING = 2; 

    public static final int mainServerPort = 12345; 
    public static final int[] SERVER_PORTS = {23456, 34567,45678};
    public static final int SERVER_PORT0 = 23456; 
    public static final int SERVER_PORT1 = 34567; 
    public static final int SERVER_PORT2 = 45678; 
    public static final String serverAddresses="localhost";
}
